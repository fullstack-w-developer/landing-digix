export default function changeCurrency(num){
    return Number(num.toFixed(3)).toLocaleString()
}