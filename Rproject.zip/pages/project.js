import React from 'react'

const Project = () => {
  return (
    <div>project</div>
  )
}

export default Project