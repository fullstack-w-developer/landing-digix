"use strict";
exports.id = 614;
exports.ids = [614];
exports.modules = {

/***/ 7505:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export Navbar */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__);




const Navbar = ()=>{
    const { 0: menu , 1: setMenu  } = useState(false);
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: `${menu ? "cover-body active" : "cover-body"}`,
                onClick: ()=>setMenu(false)
            }),
            /*#__PURE__*/ _jsx("nav", {
                children: /*#__PURE__*/ _jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ _jsxs("div", {
                        className: "content",
                        children: [
                            /*#__PURE__*/ _jsx("div", {
                                className: "btn-menu-responcive",
                                onClick: ()=>setMenu(true)
                                ,
                                children: /*#__PURE__*/ _jsx(FaBars, {})
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "logo",
                                children: /*#__PURE__*/ _jsx("img", {
                                    src: "image/logoFa.png",
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ _jsxs("div", {
                                className: `${menu ? "links active" : "links"}`,
                                children: [
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "logo-responsive",
                                        children: /*#__PURE__*/ _jsx("img", {
                                            src: "image/logoFa.png",
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ _jsxs("ul", {
                                        children: [
                                            /*#__PURE__*/ _jsx("li", {
                                                children: /*#__PURE__*/ _jsx(Link, {
                                                    href: "/",
                                                    children: "\u062E\u0631\u06CC\u062F \u0648 \u0641\u0631\u0648\u0634 "
                                                })
                                            }),
                                            /*#__PURE__*/ _jsx("li", {
                                                children: /*#__PURE__*/ _jsx(Link, {
                                                    href: "/",
                                                    children: "\u0634\u0631\u0627\u06CC\u0637 \u0648\u0642\u0648\u0627\u0646\u06CC\u0646"
                                                })
                                            }),
                                            /*#__PURE__*/ _jsx("li", {
                                                children: /*#__PURE__*/ _jsx(Link, {
                                                    href: "/",
                                                    children: "\u0628\u0644\u0627\u06AF"
                                                })
                                            }),
                                            /*#__PURE__*/ _jsx("li", {
                                                children: /*#__PURE__*/ _jsx(Link, {
                                                    href: "/",
                                                    children: "\u062F\u0631\u0628\u0627\u0631\u0647 \u0645\u0627"
                                                })
                                            }),
                                            /*#__PURE__*/ _jsx("li", {
                                                children: /*#__PURE__*/ _jsx(Link, {
                                                    href: "/",
                                                    children: "\u062A\u0645\u0627\u0633 \u0628\u0627 \u0645\u0627"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "auth",
                                children: /*#__PURE__*/ _jsxs("ul", {
                                    className: "btn-group",
                                    children: [
                                        /*#__PURE__*/ _jsx("li", {
                                            children: /*#__PURE__*/ _jsx(Link, {
                                                href: "/",
                                                className: "login",
                                                children: "\u0648\u0631\u0648\u062F"
                                            })
                                        }),
                                        /*#__PURE__*/ _jsx("li", {
                                            className: "register",
                                            children: /*#__PURE__*/ _jsx(Link, {
                                                href: "/",
                                                children: "\u062B\u0628\u062A \u0646\u0627\u0645"
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};


/***/ })

};
;